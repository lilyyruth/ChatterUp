﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatApp
{
    public partial class frmChatApp : Form
    {
        public frmChatApp()
        {
            InitializeComponent();
        }

        //Lily Crowe
        //April 1, 2018 
        //This is my chat app where people are able to talk to each other 
        //with help of a database.

        private void frmChatApp_Load(object sender, EventArgs e)
        {
            //when the form loads the Login grpbox is the only thing shown 
            grpLogin.Visible = true;
            grpSignup.Visible = false;
            grpSuccess.Visible = false;
            //stops timer
            timMessages.Stop();
        }

        //global variable for the user id in switching between group boxes
        //when a new user logs in it gets updated.
        int uID;
        private void btnLogin_Click(object sender, EventArgs e)
        {
            //gets the user's input
            string email = txtEmail.Text;
            string password = txtPassword.Text;

            //checks to make sure the user entered something
            if (email == "" || password == "")
            {
                //displays message box if they did not
                MessageBox.Show("Please enter your information", "Invalid Input");
            }
            else
            {
                //checks to see if the user entered the correct email and password
                Login check = new Login(email, password);
                //If the email is incorret a message box pops up and does not log in the user
                if (check.SuccessUsername == false)
                {
                    MessageBox.Show("Your email is not registered with our app.\nMaybe you should sign up! We would be happy to have you!", "Something Went Wrong");
                    txtEmail.Focus();
                }
                //if both the email and the password are correct it logs the user in
                else if (check.SuccessPassword == true)
                {
                    //hides login and shows login successful 
                    grpMessages.Visible = true;
                    grpLogin.Visible = false;
                    txtMessage.Focus();
                    //sets the current logged in user 
                    uID = check.Id;
                    //starts the timer 
                    timMessages.Start();
                    //sets the accept button to Send
                    this.AcceptButton = btnSend;
                }
                //If the password is wrong a message box appears informing the user of it
                else
                {
                    MessageBox.Show("Oh no your email did not match your password please try again.", "Something Went Wrong");
                    txtPassword.Clear();
                    txtPassword.Focus();
                }
            }
        }

        private void lblSignUp_Click(object sender, EventArgs e)
        {
            //makes the 
            this.AcceptButton = btnSignUP;
            //clears everything so when the user goes back to login there will be nothing there 
            txtEmail.Clear();
            txtPassword.Clear();
            //shows sign up page 
            grpSignup.Visible = true;
            grpLogin.Visible = false;
            txtSFirst.Focus();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //makes the login page visible again
            grpLogin.Visible = true;
            grpSuccess.Visible = false;
            txtEmail.Clear();
            txtPassword.Clear();
            txtEmail.Focus();
            //makes the Login button the accept button
            this.AcceptButton = btnLogin;
        }

        private void btnLogOut1_Click(object sender, EventArgs e)
        {
            //makes the login page visible again with features cleared and timer stopped
            grpLogin.Visible = true;
            grpMessages.Visible = false;
            txtEmail.Clear();
            txtPassword.Clear();
            txtEmail.Focus();
            timMessages.Stop();
            lstMessages.Items.Clear();
            txtMessage.Clear();
            //makes the Login button the accept button
            this.AcceptButton = btnLogin;
        }

        private void btnSignUP_Click(object sender, EventArgs e)
        {
            //gets user input
            string email = txtSEmail.Text.ToLower();
            string password = txtSPass.Text;
            string first = txtSFirst.Text;
            string last = txtSLast.Text;

            //makes sure the user entered something
            if (email == "" || password == "" || first == "" || last == "")
            {
                MessageBox.Show("Please add your information!", "Error");
            }
            else
            {
                //gets today's date
                DateTimeOffset date = DateTimeOffset.Now;

                //checks the email against the database
                Login checkEmail = new Login(email, password);

                //If the email exists the user needs to choose a different email
                if (checkEmail.SuccessUsername == true)
                {
                    //message box appears
                    MessageBox.Show("This email already exists.", "Error");
                    txtSEmail.SelectAll();
                }
                else
                {
                    //the new user is created
                    CreateUser newUser = new CreateUser(email, password, first, last);
                    //everything is cleared
                    txtSFirst.Clear();
                    txtSLast.Clear();
                    txtSEmail.Clear();
                    txtSPass.Clear();
                    txtSFirst.Focus();
                    //tells user that everything was a success
                    MessageBox.Show("User created successfully!", "Yay!!");
                }
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            //gets message from the message box
            string message = txtMessage.Text;
            //sends message to datatbase, the userID is from the global variable which is set when a user logs in.
            NewMessage NM = new NewMessage(uID, message);
            //adds message to database 
            lstMessages.Items.Insert(0, " ");
            lstMessages.Items.Insert(0, NM.DateCreated);
            lstMessages.Items.Insert(0, message);
            lstMessages.Items.Insert(0, Convert.ToString(NM.FirstName)+ " " + Convert.ToString(NM.LastName));
            //clears the textbox where the user inputs the message 
            txtMessage.Clear();
        }

        private void timMessages_Tick(object sender, EventArgs e)
        {
            ////checks the database for how many rows are in the database 
            Update numMessages = new ChatApp.Update();

            //counts the number of messages in the database
            int numberM = (numMessages.NumOfMessages * 4 - 1);
            
            //counts number of items in the listbox
            int numI = lstMessages.Items.Count;

            //checks to see if the number of items collorates with the number of messsages in the table
            //the reason there is a 76 is the list box is counting 76 less items then it should be 
            //but with the 76 it works properly. 
            if (!((numI + 76) == numberM))
           {
                //calls LoadMessages function
                LoadMessages();
            }
        }

        /// <summary>
        /// This method loads the message box with the messages 
        /// </summary>
        private void LoadMessages()
        {
            //clears the list box 
            lstMessages.Items.Clear();

            //recieves all messages from the database
            Update updateMessages = new ChatApp.Update(0);

            //reloads the list box with all the messages, newest being at the top of the listbox 
            //gets each message from the database based on the row number, it loops through a datatable
            int numOfRows = updateMessages.dtMessages.Rows.Count;
            for (int i = numOfRows -1; i >= 0; i--)
            {
                //puts each row in a variable to be analyzed 
                DataRow row = updateMessages.dtMessages.Rows[i];
                //sets message attributes
                string firstName = Convert.ToString(row["First"]);
                string lastName = Convert.ToString(row["Last"]);
                string created = Convert.ToString(row["Created"]);
                string message = Convert.ToString(row["Content"]);

                //adds the very first (most recent) message to the listbox
                if (i == numOfRows - 1)
                {
                    lstMessages.Items.Add(Convert.ToString(firstName) + " " + Convert.ToString(lastName));
                    lstMessages.Items.Add(message);
                    lstMessages.Items.Add(created);
                }
                //adds the rest of the messages
                else
                {
                    lstMessages.Items.Add(" ");
                    lstMessages.Items.Add(Convert.ToString(firstName) + " " + Convert.ToString(lastName));
                    lstMessages.Items.Add(message);
                    lstMessages.Items.Add(created);
                }
            }
        }

        private void lblReturn_Click(object sender, EventArgs e)
        {
            //makes Login button the accept button 
            this.AcceptButton = btnLogin;
            //returns the user to the login page
            grpSignup.Visible = false;
            grpLogin.Visible = true;
            txtEmail.Focus();
        }

        //the next four mousehover and whatnot is to features to the form.
        private void lblReturn_MouseHover(object sender, EventArgs e)
        {
            lblReturn.ForeColor = Color.WhiteSmoke;
        }

        private void lblReturn_MouseLeave(object sender, EventArgs e)
        {
            lblReturn.ForeColor = Color.Black;
        }

        private void lblSUP_MouseHover(object sender, EventArgs e)
        {
            lblSUP.ForeColor = Color.WhiteSmoke;
        }

        private void lblSUP_MouseLeave(object sender, EventArgs e)
        {
            lblSUP.ForeColor = Color.Black;
        }

    }
}
