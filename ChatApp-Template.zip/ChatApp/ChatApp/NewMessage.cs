﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Net.NetworkInformation;

namespace ChatApp
{
    class NewMessage
    {
        public int ID { get; set; }
        public string DateCreated { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        
        /// <summary>
        /// empty contructor
        /// </summary>
        public NewMessage()
        {

        }

        /// <summary>
        /// This will create a new message in the database 
        /// </summary>
        /// <param name="idSentIn"></param>
        /// <param name="datecreated"></param>
        /// <param name="message"></param>
        public NewMessage(int idSentIn,string message)
        {
            //creates a new list of SQL parameters
            List<SqlParameter> sqlParams1 = new List<SqlParameter>();

            //adds parameters to the SQL parameters list
            sqlParams1.Add(new SqlParameter("@userId", idSentIn));

            //calls the store procedure 
            DataTable dtUser = ChatApp.DAL.ExecuteStorePro("GetUserFromId", sqlParams1);
            //checks to see if the email exists in the database
            if (dtUser.Rows != null && dtUser.Rows.Count == 1)
            {
                //reads through the row
                DataRow row = dtUser.Rows[0];
                this.ID = Convert.ToInt32(row["Id"]);
                this.FirstName = Convert.ToString(row["First"]);
                this.LastName = Convert.ToString(row["Last"]);
            }

            //creates another list of SQL parameters 
            List<SqlParameter> sqlParams2 = new List<SqlParameter>();
            sqlParams2.Add(new SqlParameter("@content", message));
            sqlParams2.Add(new SqlParameter("@userId", ID));
            //gets mac address
            var machineAddress =
            (
                from nic in NetworkInterface.GetAllNetworkInterfaces()
                where nic.OperationalStatus == OperationalStatus.Up
                select nic.GetPhysicalAddress().ToString()
            ).FirstOrDefault();
            sqlParams2.Add(new SqlParameter("@machineId", machineAddress));

            //calls the SQL stored procedure to insert the message into the data table 
            DataTable dtMessage = ChatApp.DAL.ExecuteStorePro("InsertMessage", sqlParams2);
            //reads through the row
            DataRow row1 = dtMessage.Rows[0];
            //gets the password
            this.DateCreated = Convert.ToString(row1["Created"]);
        }
    }
}
