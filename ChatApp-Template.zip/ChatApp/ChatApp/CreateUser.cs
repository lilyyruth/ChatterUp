﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ChatApp
{
    class CreateUser
    {
        public bool RealEmail { get; set; }

        /// <summary>
        /// Empty constructor 
        /// </summary>
        public CreateUser()
        {

        }

        /// <summary>
        /// Adds a new user to the database
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <param name="date"></param>
        /// <param name="first"></param>
        /// <param name="last"></param>
        public CreateUser(string email, string password, string first, string last)
        {
            //creates a new list of SQL parameters
            List<SqlParameter> sqlParams = new List<SqlParameter>();

            //adds parameters to the SQL parameters list
            sqlParams.Add(new SqlParameter("@email", email));
            sqlParams.Add(new SqlParameter("@password", password));
            sqlParams.Add(new SqlParameter("@firstName", first));
            sqlParams.Add(new SqlParameter("@lastName", last));

            //calls the SQL stored procedure to recieve the datatable
            DataTable dtUser = ChatApp.DAL.ExecuteStorePro("CreateUser", sqlParams);
            this.RealEmail = SendEmail.SendEmailNU(email, first);
        }
    }
}
