﻿namespace ChatApp
{
    partial class frmChatApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChatApp));
            this.grpSuccess = new System.Windows.Forms.GroupBox();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblSuccess = new System.Windows.Forms.Label();
            this.grpLogin = new System.Windows.Forms.GroupBox();
            this.lblSUP = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblPass = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.grpSignup = new System.Windows.Forms.GroupBox();
            this.txtSPass = new System.Windows.Forms.TextBox();
            this.txtSEmail = new System.Windows.Forms.TextBox();
            this.txtSLast = new System.Windows.Forms.TextBox();
            this.lblReturn = new System.Windows.Forms.Label();
            this.lblFirst = new System.Windows.Forms.Label();
            this.lblLast = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtSFirst = new System.Windows.Forms.TextBox();
            this.lblEm = new System.Windows.Forms.Label();
            this.btnSignUP = new System.Windows.Forms.Button();
            this.grpMessages = new System.Windows.Forms.GroupBox();
            this.lstMessages = new System.Windows.Forms.ListBox();
            this.btnLogOut1 = new System.Windows.Forms.Button();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.timMessages = new System.Windows.Forms.Timer(this.components);
            this.grpSuccess.SuspendLayout();
            this.grpLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpSignup.SuspendLayout();
            this.grpMessages.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // grpSuccess
            // 
            this.grpSuccess.BackColor = System.Drawing.Color.PaleTurquoise;
            this.grpSuccess.Controls.Add(this.btnLogout);
            this.grpSuccess.Controls.Add(this.lblSuccess);
            this.grpSuccess.Location = new System.Drawing.Point(12, 6);
            this.grpSuccess.Name = "grpSuccess";
            this.grpSuccess.Size = new System.Drawing.Size(441, 444);
            this.grpSuccess.TabIndex = 0;
            this.grpSuccess.TabStop = false;
            this.grpSuccess.Visible = false;
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(311, 31);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(121, 43);
            this.btnLogout.TabIndex = 2;
            this.btnLogout.Text = "LOG OUT";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lblSuccess
            // 
            this.lblSuccess.Font = new System.Drawing.Font("Tw Cen MT Condensed", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuccess.Location = new System.Drawing.Point(67, 146);
            this.lblSuccess.Name = "lblSuccess";
            this.lblSuccess.Size = new System.Drawing.Size(311, 138);
            this.lblSuccess.TabIndex = 0;
            this.lblSuccess.Text = "LOGIN WAS SUCCESSFUL";
            this.lblSuccess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpLogin
            // 
            this.grpLogin.BackColor = System.Drawing.Color.LightGray;
            this.grpLogin.Controls.Add(this.lblSUP);
            this.grpLogin.Controls.Add(this.pictureBox1);
            this.grpLogin.Controls.Add(this.txtPassword);
            this.grpLogin.Controls.Add(this.txtEmail);
            this.grpLogin.Controls.Add(this.lblPass);
            this.grpLogin.Controls.Add(this.lblEmail);
            this.grpLogin.Controls.Add(this.btnLogin);
            this.grpLogin.Location = new System.Drawing.Point(12, 6);
            this.grpLogin.Name = "grpLogin";
            this.grpLogin.Size = new System.Drawing.Size(441, 459);
            this.grpLogin.TabIndex = 1;
            this.grpLogin.TabStop = false;
            // 
            // lblSUP
            // 
            this.lblSUP.AutoSize = true;
            this.lblSUP.Font = new System.Drawing.Font("Tw Cen MT Condensed", 18.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSUP.Location = new System.Drawing.Point(178, 331);
            this.lblSUP.Name = "lblSUP";
            this.lblSUP.Size = new System.Drawing.Size(80, 29);
            this.lblSUP.TabIndex = 2;
            this.lblSUP.Text = "Sign Up";
            this.lblSUP.Click += new System.EventHandler(this.lblSignUp_Click);
            this.lblSUP.MouseLeave += new System.EventHandler(this.lblSUP_MouseLeave);
            this.lblSUP.MouseHover += new System.EventHandler(this.lblSUP_MouseHover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ChatApp.Properties.Resources.ChatterUp;
            this.pictureBox1.Location = new System.Drawing.Point(6, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(429, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Tw Cen MT Condensed", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(193, 245);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(210, 36);
            this.txtPassword.TabIndex = 1;
            this.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Tw Cen MT Condensed", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(136, 164);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(267, 36);
            this.txtEmail.TabIndex = 0;
            this.txtEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPass
            // 
            this.lblPass.AutoSize = true;
            this.lblPass.Font = new System.Drawing.Font("Tw Cen MT Condensed", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPass.Location = new System.Drawing.Point(24, 242);
            this.lblPass.Name = "lblPass";
            this.lblPass.Size = new System.Drawing.Size(163, 47);
            this.lblPass.TabIndex = 2;
            this.lblPass.Text = "Password:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Tw Cen MT Condensed", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(24, 161);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(106, 47);
            this.lblEmail.TabIndex = 1;
            this.lblEmail.Text = "Email:";
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Tw Cen MT Condensed", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(136, 365);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(166, 57);
            this.btnLogin.TabIndex = 3;
            this.btnLogin.Text = "LOGIN";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // grpSignup
            // 
            this.grpSignup.BackColor = System.Drawing.Color.LightGray;
            this.grpSignup.Controls.Add(this.txtSPass);
            this.grpSignup.Controls.Add(this.txtSEmail);
            this.grpSignup.Controls.Add(this.txtSLast);
            this.grpSignup.Controls.Add(this.lblReturn);
            this.grpSignup.Controls.Add(this.lblFirst);
            this.grpSignup.Controls.Add(this.lblLast);
            this.grpSignup.Controls.Add(this.lblPassword);
            this.grpSignup.Controls.Add(this.txtSFirst);
            this.grpSignup.Controls.Add(this.lblEm);
            this.grpSignup.Controls.Add(this.btnSignUP);
            this.grpSignup.Location = new System.Drawing.Point(12, 6);
            this.grpSignup.Name = "grpSignup";
            this.grpSignup.Size = new System.Drawing.Size(441, 459);
            this.grpSignup.TabIndex = 6;
            this.grpSignup.TabStop = false;
            // 
            // txtSPass
            // 
            this.txtSPass.Location = new System.Drawing.Point(149, 262);
            this.txtSPass.Name = "txtSPass";
            this.txtSPass.PasswordChar = '*';
            this.txtSPass.Size = new System.Drawing.Size(244, 36);
            this.txtSPass.TabIndex = 3;
            this.txtSPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSEmail
            // 
            this.txtSEmail.Location = new System.Drawing.Point(110, 188);
            this.txtSEmail.Name = "txtSEmail";
            this.txtSEmail.Size = new System.Drawing.Size(283, 36);
            this.txtSEmail.TabIndex = 2;
            this.txtSEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSLast
            // 
            this.txtSLast.Location = new System.Drawing.Point(158, 114);
            this.txtSLast.Name = "txtSLast";
            this.txtSLast.Size = new System.Drawing.Size(235, 36);
            this.txtSLast.TabIndex = 1;
            this.txtSLast.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblReturn
            // 
            this.lblReturn.AutoSize = true;
            this.lblReturn.Font = new System.Drawing.Font("Tw Cen MT Condensed", 18.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn.Location = new System.Drawing.Point(144, 327);
            this.lblReturn.Name = "lblReturn";
            this.lblReturn.Size = new System.Drawing.Size(148, 29);
            this.lblReturn.TabIndex = 9;
            this.lblReturn.Text = "Return to Login";
            this.lblReturn.Click += new System.EventHandler(this.lblReturn_Click);
            this.lblReturn.MouseLeave += new System.EventHandler(this.lblReturn_MouseLeave);
            this.lblReturn.MouseHover += new System.EventHandler(this.lblReturn_MouseHover);
            // 
            // lblFirst
            // 
            this.lblFirst.AutoSize = true;
            this.lblFirst.Location = new System.Drawing.Point(31, 43);
            this.lblFirst.Name = "lblFirst";
            this.lblFirst.Size = new System.Drawing.Size(123, 31);
            this.lblFirst.TabIndex = 8;
            this.lblFirst.Text = "First Name:";
            // 
            // lblLast
            // 
            this.lblLast.AutoSize = true;
            this.lblLast.Location = new System.Drawing.Point(31, 117);
            this.lblLast.Name = "lblLast";
            this.lblLast.Size = new System.Drawing.Size(121, 31);
            this.lblLast.TabIndex = 7;
            this.lblLast.Text = "Last Name:";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(31, 265);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(115, 31);
            this.lblPassword.TabIndex = 6;
            this.lblPassword.Text = "Password: ";
            // 
            // txtSFirst
            // 
            this.txtSFirst.Location = new System.Drawing.Point(160, 40);
            this.txtSFirst.Name = "txtSFirst";
            this.txtSFirst.Size = new System.Drawing.Size(233, 36);
            this.txtSFirst.TabIndex = 0;
            this.txtSFirst.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblEm
            // 
            this.lblEm.AutoSize = true;
            this.lblEm.Location = new System.Drawing.Point(31, 191);
            this.lblEm.Name = "lblEm";
            this.lblEm.Size = new System.Drawing.Size(73, 31);
            this.lblEm.TabIndex = 4;
            this.lblEm.Text = "Email:";
            // 
            // btnSignUP
            // 
            this.btnSignUP.Font = new System.Drawing.Font("Tw Cen MT Condensed", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignUP.Location = new System.Drawing.Point(135, 359);
            this.btnSignUP.Name = "btnSignUP";
            this.btnSignUP.Size = new System.Drawing.Size(166, 57);
            this.btnSignUP.TabIndex = 4;
            this.btnSignUP.Text = "SIGN UP";
            this.btnSignUP.UseVisualStyleBackColor = true;
            this.btnSignUP.Click += new System.EventHandler(this.btnSignUP_Click);
            // 
            // grpMessages
            // 
            this.grpMessages.BackColor = System.Drawing.Color.LightGray;
            this.grpMessages.Controls.Add(this.lstMessages);
            this.grpMessages.Controls.Add(this.btnLogOut1);
            this.grpMessages.Controls.Add(this.btnSend);
            this.grpMessages.Controls.Add(this.txtMessage);
            this.grpMessages.Controls.Add(this.picLogo);
            this.grpMessages.Location = new System.Drawing.Point(12, 6);
            this.grpMessages.Name = "grpMessages";
            this.grpMessages.Size = new System.Drawing.Size(441, 459);
            this.grpMessages.TabIndex = 6;
            this.grpMessages.TabStop = false;
            this.grpMessages.Visible = false;
            // 
            // lstMessages
            // 
            this.lstMessages.Font = new System.Drawing.Font("Tw Cen MT Condensed", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstMessages.FormattingEnabled = true;
            this.lstMessages.HorizontalScrollbar = true;
            this.lstMessages.ItemHeight = 23;
            this.lstMessages.Location = new System.Drawing.Point(10, 161);
            this.lstMessages.Name = "lstMessages";
            this.lstMessages.Size = new System.Drawing.Size(420, 280);
            this.lstMessages.TabIndex = 10;
            // 
            // btnLogOut1
            // 
            this.btnLogOut1.Location = new System.Drawing.Point(311, 21);
            this.btnLogOut1.Name = "btnLogOut1";
            this.btnLogOut1.Size = new System.Drawing.Size(118, 46);
            this.btnLogOut1.TabIndex = 9;
            this.btnLogOut1.Text = "LOG OUT";
            this.btnLogOut1.UseVisualStyleBackColor = true;
            this.btnLogOut1.Click += new System.EventHandler(this.btnLogOut1_Click);
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(329, 87);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(106, 57);
            this.btnSend.TabIndex = 8;
            this.btnSend.Text = "SEND";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(6, 88);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMessage.Size = new System.Drawing.Size(314, 56);
            this.txtMessage.TabIndex = 7;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::ChatApp.Properties.Resources.ChatterUp;
            this.picLogo.Location = new System.Drawing.Point(9, 21);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(249, 53);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo.TabIndex = 5;
            this.picLogo.TabStop = false;
            // 
            // timMessages
            // 
            this.timMessages.Enabled = true;
            this.timMessages.Interval = 1000;
            this.timMessages.Tick += new System.EventHandler(this.timMessages_Tick);
            // 
            // frmChatApp
            // 
            this.AcceptButton = this.btnLogin;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 477);
            this.Controls.Add(this.grpMessages);
            this.Controls.Add(this.grpLogin);
            this.Controls.Add(this.grpSignup);
            this.Controls.Add(this.grpSuccess);
            this.Font = new System.Drawing.Font("Tw Cen MT Condensed", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "frmChatApp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chatter Up";
            this.Load += new System.EventHandler(this.frmChatApp_Load);
            this.grpSuccess.ResumeLayout(false);
            this.grpLogin.ResumeLayout(false);
            this.grpLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpSignup.ResumeLayout(false);
            this.grpSignup.PerformLayout();
            this.grpMessages.ResumeLayout(false);
            this.grpMessages.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpSuccess;
        private System.Windows.Forms.Label lblSuccess;
        private System.Windows.Forms.GroupBox grpLogin;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblPass;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblSUP;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.GroupBox grpSignup;
        private System.Windows.Forms.Button btnSignUP;
        private System.Windows.Forms.TextBox txtSPass;
        private System.Windows.Forms.TextBox txtSEmail;
        private System.Windows.Forms.TextBox txtSLast;
        private System.Windows.Forms.Label lblReturn;
        private System.Windows.Forms.Label lblFirst;
        private System.Windows.Forms.Label lblLast;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtSFirst;
        private System.Windows.Forms.Label lblEm;
        private System.Windows.Forms.GroupBox grpMessages;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Button btnLogOut1;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.ListBox lstMessages;
        private System.Windows.Forms.Timer timMessages;
    }
}

