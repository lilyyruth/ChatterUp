﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace ChatApp
{
    public static class DAL
    {
        /// <summary>
        /// This function will recieve data from a Database
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="sqlParama"></param>
        /// <returns>A filled DataTable</returns>
        public static DataTable ExecuteStorePro(string spName, List<SqlParameter> sqlParams = null)
        {
            //creates a connection string
            string connection = ConfigurationManager.ConnectionStrings["ChatApp"].ToString();
            //creates a new sqlconnection
            SqlConnection conn = new SqlConnection();
            //creates a new data table
            DataTable dt = new DataTable();

            try
            {
                //estabishes new connection
                conn = new SqlConnection(connection);
                //opens the connection
                conn.Open();
                //creates a new sql command
                SqlCommand command = new SqlCommand(spName, conn);
                //executes the command
                command.CommandType = CommandType.StoredProcedure;

                //goes through the commands
                if (sqlParams != null)
                {
                    command.Parameters.AddRange(sqlParams.ToArray());
                }

                //executes command
                SqlDataReader dr = command.ExecuteReader();
                //loads the datatable with data
                dt.Load(dr);
                command.Parameters.Clear();
            }
            catch (Exception ex)
            {
                //throws away any exceptions that occur
                throw ex;
            }
            finally
            {
                //you always need to close your 
                //connection no matter what
                conn.Close();
            }
            //returns datatable
            return dt;
        }
    }
}
