﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;

namespace ChatApp
{
    public static class SendEmail
    {
        //smpt server
        public const string GmailServer = "smtp.gmail.com";
        //connecting port
        public const int Port = 587;

        public static bool SendEmailNU(string NUEmail, string firstname) 
        {
            try
            {
                //connects to google server 
                //you can use different email providers I just used google
                SmtpClient mailServer = new SmtpClient(GmailServer, Port);
                //enables ssl
                mailServer.EnableSsl = true;

                //Provide your email id with your password.
                //Enter the app-specfic password if two-step authentication is enabled.
                mailServer.Credentials = new System.Net.NetworkCredential("enter email", "enter password");

                //Senders email.
                string from = "chatteruptoday@gmail.com";
                //Receiver email
                string to = NUEmail;

                MailMessage msg = new MailMessage(from, to);

                //Subject of the email.
                msg.Subject = "Welcome to Chatter Up!";

                //Specify the body of the email here.
                msg.Body = "Hey " + firstname + "!! You have successful become a user of our lovely app. " +
                    "The purpose of this app is for people to be able to communicate" +
                    " with each other. Thanks for joining us! Have a great day :)";

                //sends email to user
                mailServer.Send(msg);

                //if the email is valid and email is sent a true is returned
                return true;
            }
            catch (Exception ex)
            {
                //returns false if any issues are run into.
                return false;
            }
        }
    }
}
