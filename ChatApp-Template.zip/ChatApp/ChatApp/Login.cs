﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ChatApp
{
    class Login
    {
        //declares the attributes
        public int Id { get; set; }
        public string Password { get; set; }
        public bool SuccessUsername { get; set; }
        public bool SuccessPassword { get; set; }

        /// <summary>
        /// Empty Constructor
        /// </summary>
        public Login()
        {

        }

        /// <summary>
        /// Checks to see if the email matches
        /// the password, and if the email does not 
        /// exist it creates a new user 
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        public Login(string email, string password)
        {
            //creates a new list of SQL parameters
            List<SqlParameter> sqlParams1 = new List<SqlParameter>();

            //adds new sql parameter
            sqlParams1.Add(new SqlParameter("@email", email));
            
            //adds parameters to the SQL parameters list
            DataTable dtEmail = ChatApp.DAL.ExecuteStorePro("VerifyEmail", sqlParams1);

            //checks to see if the email exists in the database
            if (dtEmail.Rows != null && dtEmail.Rows.Count == 1)
            {
                //reads through the row
                DataRow row = dtEmail.Rows[0];
                //gets the id
                this.Id = Convert.ToInt32(row["Id"]);
                //sets the username as a success
                this.SuccessUsername = true;
                //creates a seconf list of parameters 
                List<SqlParameter> sqlParams2 = new List<SqlParameter>();
                //adds parameters to the list
                    sqlParams2.Add(new SqlParameter("@userId", Id));

                //gets another datatable to confirm that the password, id, and email matches
                DataTable dtEmailNPass = ChatApp.DAL.ExecuteStorePro("GetUserFromId", sqlParams2);

                //makes sure one row is returned 
                if (dtEmailNPass.Rows != null && dtEmailNPass.Rows.Count == 1)
                {
                    //reads through the row
                    DataRow row1 = dtEmailNPass.Rows[0];
                    //gets the password
                    this.Password = Convert.ToString(row1["Password"]);
                    if (password == this.Password)
                    {
                        //if true the password was a success
                        this.SuccessPassword = true;
                    }
                    else
                    {
                        //if false the password did not match 
                        this.SuccessPassword = false;
                    }
                }
            }
            else
            {
                //the email does not exists in the database
               this.SuccessUsername = false;
            }

        }

    }
}
