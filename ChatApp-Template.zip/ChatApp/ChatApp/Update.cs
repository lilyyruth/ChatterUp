﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ChatApp
{
    class Update
    {
        public int NumOfMessages { get; set; }
        public DataTable dtMessages { get; set; }

        /// <summary>
        /// Gets all the rows in the messages table 
        /// </summary>
        public Update()
        {
            //gets the data table from the database
            DataTable dtMessages = ChatApp.DAL.ExecuteStorePro("GetAllMessages", null);
            //Counts how many messages are in that table
            int messages = dtMessages.Rows.Count;
            this.NumOfMessages = dtMessages.Rows.Count;
        }

        /// <summary>
        /// Gets a message in the messages table based on it's ID
        /// </summary>
        /// <param name="messageid"></param>
        public Update(int messageid)
        {
            //creates a new list of SQL parameters
            List<SqlParameter> sqlParams = new List<SqlParameter>();

            //adds parameters to the SQL parameters list
            sqlParams.Add(new SqlParameter("@messageId", messageid));

            //calls the stored procedure from the database to get the message and it's info 
            this.dtMessages = ChatApp.DAL.ExecuteStorePro("GetMessagesLC", sqlParams);

        }
    }
}
